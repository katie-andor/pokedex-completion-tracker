<?php
require_once "config.php";
$pdo = getDBConnection();
$sql = "Select * from pokemon_data";
if($stmt = $pdo->prepare($sql)){
    if($stmt->execute()){
        $rows = $stmt->fetchAll();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>Gen 1 Pokedex Tracker</title>
    <link rel="icon" type="image/x-icon" href="Poké_Ball_icon.svg.png">
</head>
<body class="container text-bg-danger p-3">
<div class="text-center">
    <h1> Gen 1 Pokedex Tracker</h1>
    <p>Check off the Pokemon you've caught, hit submit, and see your progress percentage!</p>
    <h2>Also check out the <a class="link-info" href="random_fun_facts.php" >Gen 1 Fun Facts</a> section!</h2>
    <form action="pokedex_completion_calculator.php" method="post">
        <table class="table table-info table table-striped text-center">
            <tr>
                <th>Number</th>
                <th>Name</th>
                <th>Primary Typing</th>
                <th>Secondary Typing</th>
                <th>Height (m)</th>
                <th>Weight (kg)</th>
                <th>Male Percentage</th>
                <th>Female Percentage</th>
                <th>Capture Rate</th>
            </tr>
            <?php
                foreach ($rows as $row){
            ?>
                <tr>
                    <td><?= $row['number'] ?></td>
                    <td>
                        <?= $row['name'] ?>
                        <input type="checkbox" name="checked_boxes[<?= $row["number"] ?>]" value="<?= $row["name"] ?>">
                    </td>
                    <td class="text-capitalize"><?= $row['type1'] ?></td>
                    <td class="text-capitalize"><?= $row['type2'] ?></td>
                    <td><?= $row['height'] ?></td>
                    <td><?= $row['weight'] ?></td>
                    <td><?= $row['male_percentage'] ?>%</td>
                    <td><?= $row['female_percentage'] ?>%</td>
                    <td><?= $row['capture_rate'] ?></td>
                </tr>
            <?php
                }
            ?>
        </table>
        <input type="submit" value="Check Progress" >
    </form>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>